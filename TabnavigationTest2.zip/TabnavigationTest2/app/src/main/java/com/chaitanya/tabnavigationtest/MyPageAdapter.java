package com.chaitanya.tabnavigationtest;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

/**
 * Created by Kanakamma on 12/14/2017.
 */

class MyPageAdapter extends FragmentStatePagerAdapter
{

    int numberoftabs;

    public MyPageAdapter(FragmentManager supportFragmentManager, int tabCount) {
        super(supportFragmentManager);
        numberoftabs=tabCount;

    }
    @Override
    public Fragment getItem(int position) {

        switch (position)
        {
            case 0: return new Firstfragment();
            case 1:return new SecondFragment();
            case 2:return new ThirdFragment();
            default:return null;
        }

    }

    @Override
    public int getCount() {
        return numberoftabs;
    }
}
