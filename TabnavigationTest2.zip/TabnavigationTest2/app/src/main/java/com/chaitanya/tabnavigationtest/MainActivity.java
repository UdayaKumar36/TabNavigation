package com.chaitanya.tabnavigationtest;

import android.support.design.widget.TabLayout;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    TabLayout tab;
    ViewPager viewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tab=findViewById(R.id.tablayout);
        viewPager=findViewById(R.id.viewpage);

        tab.addTab(tab.newTab().setText("Contacts"));
        tab.addTab(tab.newTab().setText("Whatsup"));
        tab.addTab(tab.newTab().setText("Calls"));

       MyPageAdapter adapter=new MyPageAdapter(getSupportFragmentManager(),tab.getTabCount());
       viewPager.setAdapter(adapter);

       viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tab));
       //tab.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener());
tab.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
    @Override
    public void onTabSelected(TabLayout.Tab tab) {

        viewPager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }
});


    }
}
